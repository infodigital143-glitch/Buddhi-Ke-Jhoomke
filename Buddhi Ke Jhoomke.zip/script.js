const WA_NUM = "918278646299"; 
const UPI_ID = "8278646299@ybl";
const UPI_NAME = "Buddhi Ke Jhoomke";

const products = [
    { id: 1, title: "Royal Kundan Drops", price: 899, img: "img1.jpg", desc: "Handcrafted with premium kundan stones. Dadi Amma's signature masterpiece." },
    { id: 2, title: "Antique Meenakari Jhumka", price: 650, img: "img2.jpg", desc: "Vibrant traditional Meenakari work. Lightweight and heritage-rich." },
    { id: 3, title: "Silver Oxidised Chandbali", price: 499, img: "img3.jpg", desc: "Timeless oxidised finish chandbalis for a perfect boho-ethnic look." },
    { id: 4, title: "Heritage Jadau Earrings", price: 1299, img: "img4.jpg", desc: "Elite Jadau craftsmanship. An heirloom piece that supports a cause." },
    { id: 5, title: "Pearl Floral Studs", price: 350, img: "img5.jpg", desc: "Sweet and simple pearl studs, perfect for daily elegance." },
    { id: 6, title: "Tribal Ghungroo Drops", price: 550, img: "img6.jpg", desc: "Artistic ghungroo details with a deep cultural aesthetic." },
    { id: 7, title: "Ruby Royal Jhumka", price: 799, img: "img7.jpg", desc: "Majestic jhumkas with ruby-toned stones handset with love." },
    { id: 8, title: "Temple Jewelry Motif", price: 950, img: "img8.jpg", desc: "Inspired by ancient temple art. Intricate hand-carved details." }
];

let cart = [];

// Initialize Products
function init() {
    const grid = document.getElementById('productGrid');
    grid.innerHTML = products.map(p => `
        <div class="product-card">
            <img src="${p.img}" alt="${p.title}" onclick="showProduct(${p.id})">
            <h3>${p.title}</h3>
            <div class="price">₹${p.price}</div>
            <button class="btn-details" onclick="showProduct(${p.id})">View Details</button>
        </div>
    `).join('');
}

// Show Compact Modal
function showProduct(id) {
    const p = products.find(x => x.id === id);
    document.getElementById('modalImg').src = p.img;
    document.getElementById('modalTitle').innerText = p.title;
    document.getElementById('modalPrice').innerText = '₹' + p.price;
    document.getElementById('modalDesc').innerText = p.desc;

    const btnContainer = document.querySelector('.m-btns');
    btnContainer.innerHTML = `
        <button class="btn-modal btn-m-add" onclick="handleAddToCart(${p.id})">Add to Bag</button>
        <button class="btn-modal btn-m-upi" onclick="paySingle(${p.price})">Pay via UPI (₹${p.price})</button>
        <button class="btn-modal btn-m-wa" onclick="orderWA('${p.title}', ${p.price})">Order on WhatsApp</button>
    `;

    document.getElementById('productModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function handleAddToCart(id) {
    const p = products.find(x => x.id === id);
    const found = cart.find(i => i.id === id);
    found ? found.qty++ : cart.push({...p, qty: 1});
    updateUI();
    closeModal('productModal');
}

function updateUI() {
    document.getElementById('cartCount').innerText = cart.reduce((s, i) => s + i.qty, 0);
    const list = document.getElementById('cartItems');
    list.innerHTML = cart.length === 0 ? "<p style='text-align:center;margin-top:20px;'>Your bag is empty.</p>" : "";
    
    let subtotal = 0;
    cart.forEach(item => {
        subtotal += item.price * item.qty;
        list.innerHTML += `
            <div style="display:flex; justify-content:space-between; margin-bottom:15px; align-items:center; border-bottom:1px solid #eee; padding-bottom:10px;">
                <div style="font-size:14px;"><strong>${item.title}</strong><br>₹${item.price} x ${item.qty}</div>
                <div style="display:flex; gap:10px;">
                    <button onclick="changeQty(${item.id}, -1)" style="padding:2px 8px;">-</button>
                    <button onclick="changeQty(${item.id}, 1)" style="padding:2px 8px;">+</button>
                </div>
            </div>`;
    });

    // --- DISCOUNT LOGIC ---
    let finalTotal = subtotal;
    let discountHtml = "";

    if (subtotal >= 1350) {
        let discount = Math.round(subtotal * 0.10);
        finalTotal = subtotal - discount;
        discountHtml = `
            <div class="discount-msg">🎉 Mission Discount Applied (10% OFF)</div>
            <div style="display:flex; justify-content:space-between; font-size:14px; color:#666;">
                <span>Subtotal:</span>
                <span>₹${subtotal}</span>
            </div>
            <div style="display:flex; justify-content:space-between; font-size:14px; color:red;">
                <span>Discount:</span>
                <span>-₹${discount}</span>
            </div>
        `;
    } else if (subtotal > 0) {
        discountHtml = `<div style="font-size:11px; color:#888;">Add ₹${1350 - subtotal} more to get 10% OFF!</div>`;
    }

    const footerArea = document.querySelector('.total-row');
    footerArea.previousElementSibling ? footerArea.previousElementSibling.remove() : null; // Clean old msgs
    
    // Injecting total and discount info
    document.getElementById('cartItems').insertAdjacentHTML('beforeend', `<div style="margin-top:20px;">${discountHtml}</div>`);
    document.getElementById('finalTotal').innerText = '₹' + finalTotal;
}


function changeQty(id, d) {
    const item = cart.find(x => x.id === id);
    item.qty += d;
    if (item.qty <= 0) cart = cart.filter(x => x.id !== id);
    updateUI();
}

// Payment & Orders
function paySingle(amt) {
    window.location.href = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(UPI_NAME)}&am=${amt}&cu=INR`;
}

function orderWA(title, price) {
    window.open(`https://wa.me/${WA_NUM}?text=Hi, I want to order: ${title} (₹${price})`);
}

function checkoutWA() {
    if(cart.length === 0) return;
    let msg = "*New Order - Buddhi Ke Jhoomke*%0A%0A";
    cart.forEach(i => msg += `- ${i.title} (x${i.qty})%0A`);
    msg += `%0A*Total: ${document.getElementById('finalTotal').innerText}*`;
    window.open(`https://wa.me/${WA_NUM}?text=${msg}`);
}

function checkoutUPI() {
    const total = document.getElementById('finalTotal').innerText.replace('₹', '');
    if(total == 0) return;
    window.location.href = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(UPI_NAME)}&am=${total}&cu=INR`;
}

function openCart() { document.getElementById('cartModal').style.display = 'flex'; }
function closeModal(id) { 
    document.getElementById(id).style.display = 'none'; 
    document.body.style.overflow = 'auto';
}

// Close on backdrop click
window.onclick = (e) => {
    if (e.target.classList.contains('modal-backdrop')) {
        closeModal('productModal');
        closeModal('cartModal');
    }
}

init();
